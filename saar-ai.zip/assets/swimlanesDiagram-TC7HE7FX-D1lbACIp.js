import{c as r,s as e}from"./flowDiagram-KWPJA3E3-CgomPXGv.js";import{_ as a}from"./main-BhGj_4R1.js";import"./chunk-5VM5RSS4-BqEjGteJ.js";import"./chunk-XXDRQBXY-BgJElKkk.js";import"./chunk-WEXAMYUT-BwBHRB1A.js";import"./chunk-GWA4HPMP-CODBYP9V.js";import"./channel-CgYON-Mo.js";var o=a(t=>`${e(t)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),s=o,f=r({styles:s});export{f as diagram};
